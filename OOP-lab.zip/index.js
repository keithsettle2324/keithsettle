function Movie(name) {
  this.name = name;
}
Movie.prototype.genre = function() {
  console.log(`${this.name} says SciFi`);
}
const groundHogDay = new Movie('Groundhog Day');
groundHogDay.genre = function () {
  console.log("Comedy");
{
  year: 1993,
    print: function () {
        console.log(` that was released in ${this.year}.`);
    }
}
}


const starWars = {new Movie('StarWars');
starWars.genre();
    year: 1976,
    print: function () {
        console.log(` that was released in ${this.year}.`);
    }

};
const theTerminator = {new Movie('The Terminator');
theTerminator.genre();
year: 1984,
    print: function () {
        console.log(`that was released in ${this.year}.`);
    }
};





const movies = [starWars, theTerminator, groundHogDay];
movies.forEach(movie => {
    movie.print();
});