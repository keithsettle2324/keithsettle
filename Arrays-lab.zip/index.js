const shoppingList = ['bread', 'pizza', 'chips', 'salsa', 'coffee', 'apples'];
const cart = ['bread', 'apples'];
shoppingList.splice(4,1,"tea")
shoppingList.splice(2,2,"rice","beans")
// TODO: add 'apples' to the end of the shoppingList

// TODO: add 'bread' to the front of the shoppingList

// TODO: use indexOf to replace 'coffee' with 'tea'

// TODO: use splice to replace `chips` and `salsa` with `rice` and `beans`


// TODO: put the first and the last items from your shoppingList into your cart


// now let's see what we got
console.log('shoppingList:', shoppingList);
console.log('cart:', cart);