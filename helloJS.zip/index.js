console.log('Hello, JavaScript');
console.log(6+8);
console.log('The sum of 7 + 2 =',  7+2);