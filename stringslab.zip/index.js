// Part 1:
const x = 3;
const y = 5;

// TODO: refactor the following string to use a String Template
const mathString = `The value of  ${x} + ${y}= 8`;
console.log (mathString);

// Part 2:
const name = "Homer D. Poe";
const age = 40;

// TODO: refactor the following string to use a String Template
const greeting = `Hello, my name is ${name} !\nI am ${age}  years old.`;

console.log(greeting); // prints
// Hello, my name is Homer D. Poe!
// I am 40 years old.
